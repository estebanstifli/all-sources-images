// Use destructuring with different variable names to avoid conflicts
const { dispatch: wpDispatch, select: wpSelect } = wp.data;
const { createBlock } = wp.blocks;

function addMPTBlockAndOpenModal() {

    /*
    const selectedBlockClientId = wpSelect('core/block-editor').getSelectedBlockClientId();

    const indexBlock = wp.data.select('core/block-editor').getBlocks().map(function(block) { 
        return block.clientId == selectedBlockClientId; 
    }).indexOf(true) + 1;*/


    // Create an instance of the allsi/allsi-images block
    const block = createBlock('allsi/allsi-images');

    //wpDispatch('core/block-editor').insertBlock(block, indexBlock);
    wpDispatch('core/block-editor').insertBlock(block);

    setTimeout(() => modalToExecute(block), 1);
}

function modalToExecute(block) {
    // Trigger a custom event to open the modal
    const event = new CustomEvent('openMPTModal', { detail: block });
    document.dispatchEvent(event);
}

<?php
if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * New Automatic - Post-Processing Tab
 * 
 * This tab handles image modifications after download (flip, crop, naming, alt tags, etc.)
 * Part of the new admin UI structure
 *
 * @package All_Sources_Images
 */

// Get options
$allsi_options = get_option( 'ALLSI_plugin_main_settings' );
$allsi_options = wp_parse_args( $allsi_options, $this->ALLSI_default_options_main_settings() );

// Feature availability (all options enabled in free plugin)
$allsi_checkbox_disabled = '';
$allsi_disabled = '';

// Alt language
if ( ! isset( $allsi_options['translate_alt_lang'] ) ) {
    $allsi_wp_lang  = get_bloginfo( 'language' );
    $allsi_alt_lang = substr( $allsi_wp_lang, 0, 2 );
} else {
    $allsi_alt_lang = $allsi_options['translate_alt_lang'];
}
?>

<div class="new-automatic-post-processing-tab">
    <div class="alert alert-custom alert-light-primary fade show mb-5" role="alert">
        <div class="alert-icon"><i class="flaticon-info"></i></div>
        <div class="alert-text">
            <strong><?php esc_html_e( 'Post-Processing Options', 'all-sources-images' ); ?></strong><br>
            <?php esc_html_e( 'Configure how images are processed after downloading. This includes naming conventions, image modifications, and metadata settings.', 'all-sources-images' ); ?>
        </div>
    </div>

    <form method="post" action="options.php" id="post-processing-form">
        <?php settings_fields( 'ASI-plugin-main-settings' ); ?>
        <input type="hidden" name="ALLSI_plugin_main_settings[_saving_tab]" value="post_processing">
        
        <table class="form-table">
        <!-- Image Naming Convention -->
        <tr valign="top" class="selected_image">
            <th scope="row">
                <label for="hseparator"><?php esc_html_e( 'Image Naming Convention', 'all-sources-images' ); ?></label>
            </th>
            <td class="chosen_title radio-inline">
                <label class="radio radio-outline radio-outline-2x radio-primary">
                    <input value="title" name="ALLSI_plugin_main_settings[image_filename]" type="radio" <?php checked( ! empty( $allsi_options['image_filename'] ) && $allsi_options['image_filename'] == 'title' ); ?>>
                    <span></span> <?php esc_html_e( 'Title', 'all-sources-images' ); ?>
                </label><br/>
                <label class="radio radio-outline radio-outline-2x radio-primary">
                    <input value="date" name="ALLSI_plugin_main_settings[image_filename]" type="radio" <?php checked( ! empty( $allsi_options['image_filename'] ) && $allsi_options['image_filename'] == 'date' ); ?>>
                    <span></span> <?php esc_html_e( 'Date', 'all-sources-images' ); ?>
                </label><br/>
                <label class="radio radio-outline radio-outline-2x radio-primary">
                    <input value="random" name="ALLSI_plugin_main_settings[image_filename]" type="radio" <?php checked( ! empty( $allsi_options['image_filename'] ) && $allsi_options['image_filename'] == 'random' ); ?>>
                    <span></span> <?php esc_html_e( 'Random number', 'all-sources-images' ); ?>
                </label>
            </td>
        </tr>

        <!-- Overwrite Featured Images -->
        <tr valign="top">
            <th scope="row">
                <?php esc_html_e( 'Overwrite featured images', 'all-sources-images' ); ?>
            </th>
            <td class="checkbox-list">
                <label class="checkbox">
                    <input <?php checked( ! empty( $allsi_options['rewrite_featured'] ) && $allsi_options['rewrite_featured'] == 'true' ); ?> name="ALLSI_plugin_main_settings[rewrite_featured]" type="checkbox" value="true">
                    <span></span> <?php esc_html_e( 'Overwrite', 'all-sources-images' ); ?>
                </label>
                <p class="description">
                    <?php esc_html_e( 'Warning: This option will overwrite existing featured images', 'all-sources-images' ); ?>
                </p>
            </td>
        </tr>

        <!-- Image Reuse -->
        <tr valign="top">
            <th scope="row">
                <?php esc_html_e( 'Image reuse', 'all-sources-images' ); ?>
            </th>
            <td class="checkbox-list">
                <label class="checkbox">
                    <input <?php checked( ! empty( $allsi_options['image_reuse'] ) && $allsi_options['image_reuse'] == 'true' ); ?> name="ALLSI_plugin_main_settings[image_reuse]" type="checkbox" value="true">
                    <span></span> <?php esc_html_e( 'Enable', 'all-sources-images' ); ?>
                </label>
                <p class="description">
                    <?php esc_html_e( 'Check for existing images media before downloading new ones to prevent duplicates and save storage space. Reuse is based on filename.', 'all-sources-images' ); ?>
                </p>
            </td>
        </tr>

        <!-- Image Modifications -->
        <tr valign="top" class="shuffle_image">
            <th scope="row">
                <?php esc_html_e( 'Image Modifications', 'all-sources-images' ); ?>
            </th>
            <td class="checkbox-list">
                <label class="checkbox <?php echo esc_attr( $allsi_checkbox_disabled ); ?>">
                    <input <?php checked( ! empty( $allsi_options['image_flip'] ) && $allsi_options['image_flip'] == 'true' ); ?> name="ALLSI_plugin_main_settings[image_flip]" type="checkbox" value="true" <?php echo esc_attr( $allsi_disabled ); ?>>
                    <span></span> <?php esc_html_e( 'Flip horizontally', 'all-sources-images' ); ?>
                </label>
                <label class="checkbox <?php echo esc_attr( $allsi_checkbox_disabled ); ?>">
                    <input <?php checked( ! empty( $allsi_options['image_crop'] ) && $allsi_options['image_crop'] == 'true' ); ?> name="ALLSI_plugin_main_settings[image_crop]" type="checkbox" value="true" <?php echo esc_attr( $allsi_disabled ); ?>>
                    <span></span> <?php esc_html_e( 'Crop Image by 10%', 'all-sources-images' ); ?>
                </label>
            </td>
        </tr>

        <tr>
            <td colspan="2"><hr/></td>
        </tr>

        <!-- Add ALT Attribute to Image -->
        <tr valign="top" class="based_on_bottom">
            <th scope="row">
                <label for="hseparator"><?php esc_html_e( 'Add ALT Attribute to Image', 'all-sources-images' ); ?></label>
            </th>
            <td>
                <label class="checkbox">
                    <input data-switch="true" type="checkbox" name="ALLSI_plugin_main_settings[enable_alt]" id="enable_alt" value="enable" <?php checked( ! empty( $allsi_options['enable_alt'] ) && $allsi_options['enable_alt'] == 'enable' ); ?> />
                </label>
            </td>
        </tr>

        <tr valign="top" class="show_alt" <?php echo esc_attr( ! isset( $allsi_options['enable_alt'] ) || ( $allsi_options['enable_alt'] != 'enable' ) ? 'style="display:none;"' : '' ); ?>>
            <th scope="row">
                <label for="hseparator"><?php esc_html_e( 'Alt Text from', 'all-sources-images' ); ?></label>
            </th>
            <td class="tags radio-list">
                <label class="radio">
                    <input value="source" name="ALLSI_plugin_main_settings[alt_from]" type="radio" <?php checked( ! empty( $allsi_options['alt_from'] ) && $allsi_options['alt_from'] == 'source' ); ?>><span></span> 
                    <?php esc_html_e( 'Source', 'all-sources-images' ); ?>
                </label>
                <label class="radio">
                    <input value="based_on" name="ALLSI_plugin_main_settings[alt_from]" type="radio" <?php checked( ! empty( $allsi_options['alt_from'] ) && $allsi_options['alt_from'] == 'based_on' ); ?>> <span></span>
                    <?php esc_html_e( 'Text "based_on"', 'all-sources-images' ); ?>
                </label>
            </td>
        </tr>

        <tr valign="top" class="show_alt" <?php echo esc_attr( isset( $allsi_options['enable_alt'] ) && ( $allsi_options['enable_alt'] != 'enable' ) ? 'style="display:none;"' : '' ); ?>>
            <th scope="row">
                <?php esc_html_e( 'ALT Text Translation', 'all-sources-images' ); ?>
            </th>
            <td class="checkbox-list">
                <label class="checkbox">
                    <input name="ALLSI_plugin_main_settings[translate_alt]" type="checkbox" value="true" <?php checked( ! empty( $allsi_options['translate_alt'] ) && $allsi_options['translate_alt'] == 'true' ); ?>><span></span> 
                    <?php esc_html_e( 'Translate alt text from english to', 'all-sources-images' ); ?>:
                </label>

                <select name="ALLSI_plugin_main_settings[translate_alt_lang]" class="form-control form-control-lg">
                    <?php
                    $allsi_country_choose = array(
                        __( 'German', 'all-sources-images' )    => 'de',
                        __( 'Spanish', 'all-sources-images' )   => 'es',
                        __( 'French', 'all-sources-images' )    => 'fr',
                        __( 'Italian', 'all-sources-images' )   => 'it',
                        __( 'Portuguese', 'all-sources-images' ) => 'pt-PT',
                        __( 'Dutch', 'all-sources-images' )     => 'nl',
                        __( 'Polish', 'all-sources-images' )    => 'pl',
                        __( 'Russian', 'all-sources-images' )   => 'ru',
                        __( 'Japanese', 'all-sources-images' )  => 'ja',
                        __( 'Chinese (Simplified)', 'all-sources-images' ) => 'zh-CN',
                        __( 'Korean', 'all-sources-images' )    => 'ko',
                        __( 'Arabic', 'all-sources-images' )    => 'ar',
                    );
                    ksort( $allsi_country_choose );

                    foreach ( $allsi_country_choose as $allsi_name_country => $allsi_code_country ) {
                        echo '<option value="' . esc_attr( $allsi_code_country ) . '" ' . selected( $allsi_alt_lang, $allsi_code_country, false ) . '>' . esc_html( $allsi_name_country ) . '</option>';
                    }
                    ?>
                </select>
            </td>
        </tr>

        <tr>
            <td colspan="2"><hr/></td>
        </tr>

        <!-- Add Caption Tag -->
        <tr valign="top" class="based_on_bottom">
            <th scope="row">
                <label for="hseparator"><?php esc_html_e( 'Add caption tag on image', 'all-sources-images' ); ?></label>
            </th>
            <td>
                <label class="checkbox">
                    <input data-switch="true" type="checkbox" name="ALLSI_plugin_main_settings[enable_caption]" id="enable_caption" value="enable" <?php checked( ! empty( $allsi_options['enable_caption'] ) && $allsi_options['enable_caption'] == 'enable' ); ?> />
                </label>
            </td>
        </tr>

        <tr valign="top" class="show_caption" <?php echo esc_attr( ! isset( $allsi_options['enable_caption'] ) || ( $allsi_options['enable_caption'] != 'enable' ) ? 'style="display:none;"' : '' ); ?>>
            <th scope="row">
                <label for="hseparator"><?php esc_html_e( 'Caption Format', 'all-sources-images' ); ?></label>
            </th>
            <td class="tags radio-list">
                <label class="radio">
                    <input value="author" name="ALLSI_plugin_main_settings[caption_from]" type="radio" <?php checked( ! empty( $allsi_options['caption_from'] ) && $allsi_options['caption_from'] == 'author' ); ?>><span></span> 
                    <?php esc_html_e( 'Image Author', 'all-sources-images' ); ?>
                </label>
                <label class="radio">
                    <input value="author_bank" name="ALLSI_plugin_main_settings[caption_from]" type="radio" <?php checked( ! empty( $allsi_options['caption_from'] ) && $allsi_options['caption_from'] == 'author_bank' ); ?>> <span></span>
                    <?php echo wp_kses_post( __( 'Image Author + Name of Image Bank (Example: <em>Author Name from Pixabay</em>)', 'all-sources-images' ) ); ?>
                </label>
            </td>
        </tr>
    </table>
    
    <div class="d-flex justify-content-end mt-6">
        <?php submit_button( __( 'Save Changes', 'all-sources-images' ), 'btn btn-primary', 'submit', false ); ?>
    </div>
    </form>
</div>
